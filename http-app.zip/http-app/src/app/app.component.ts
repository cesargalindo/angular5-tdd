import { Component } from '@angular/core';
import {
  HttpClient,
  HttpHeaders,
  HttpParams
} from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'http-app';
  apiRoot: String = 'http://httpbin.org';
  data: any;

  constructor(private http: HttpClient) {}

  doGET() {
    console.log('GET');
    const url = `${this.apiRoot}/get`;

    const httpOptions = {
      params: new HttpParams().set('foo', 'moo').set('limit', '25')
    };
    this.http.get(url, httpOptions).subscribe(res => { console.log(res); this.data = res; } );
  }

  doPOST() {
    console.log('POST');
    const url = `${this.apiRoot}/post`;
    const httpOptions = {
      params: new HttpParams().set('foo', 'moo').set('limit', '25')
    };
    this.http
      .post(url, { moo: 'foo', goo: 'loo' }, httpOptions)
      .subscribe(res => {
        console.log(res);
        this.data = res;
      });
  }

  doPUT() {
    console.log('PUT');
    const url = `${this.apiRoot}/put`;
    const httpOptions = {
      params: new HttpParams().set('foo', 'moo').set('limit', '25')
    };
    this.http
      .put(url, { moo: 'foo', goo: 'loo' }, httpOptions)
      .subscribe(res => {
        console.log(res);
        this.data = res;
      });
  }

  doDELETE() {
    console.log('DELETE');
    const url = `${this.apiRoot}/delete`;
    const httpOptions = {
      params: new HttpParams().set('foo', 'moo').set('limit', '25')
    };
    this.http.delete(url, httpOptions)
    .subscribe(res => {
      console.log(res);
      this.data = res;
    });
  }

  doGETAsPromise() {
    console.log('GET AS PROMISE');
    const url = `${this.apiRoot}/get`;
    this.http
      .get(url)
      .toPromise()
      .then(res => {
        console.log(res);
        this.data = res;
      });
  }

  doGETAsPromiseError() {
    console.log('GET AS PROMISE ERROR');
    const url = `${this.apiRoot}/post`;
    this.http
      .get(url)
      .toPromise()
      .then(
        res => {
          console.log(res);
          this.data = res;
        },
        msg => console.error(`Error: ${msg.status} ${msg.statusText}`)
      );
  }

  doGETAsObservableError() {
    console.log('GET AS OBSERVABLE ERROR');
    const url = `${this.apiRoot}/post`;
    this.http
      .get(url)
      .subscribe(
        res => {
          console.log(res);
          this.data = res;
        },
        msg => console.error(`Error: ${msg.status} ${msg.statusText}`)
      );
  }

  doGETWithHeaders() {
    console.log('GET WITH HEADERS');

    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: btoa('username:password')
      })
    };

    const url = `${this.apiRoot}/get`;

    this.http
      .get(url, httpOptions)
      .subscribe(
        res => {
          console.log(res);
          this.data = res;
        },
        msg => console.error(`Error: ${msg.status} ${msg.statusText}`)
      );
  }

}
